package br.com.construtor;

public class Conta {
    //atributos
	public String agencia;
	public String numero;
	public String cpfTitular;
	public String nome;
	
	
	//m�todos
	public Conta(String agencia, String numero) {
		this.agencia = agencia;
		this.numero = numero;
		this.nome = nome;
		
		
		
	}
	
	public void exibirDados() {
		System.out.println("Ag�ncia: " + this.agencia);
		System.out.println("Conta: " + this.numero);
		System.out.println("CPF do titular: " + this.cpfTitular);
		System.out.println("Nome: " + this.nome);
		
	}
}
