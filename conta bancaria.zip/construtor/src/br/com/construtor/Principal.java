package br.com.construtor;

import java.util.Scanner;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		//instancia os objetos
		Scanner leia = new Scanner(System.in);
		Conta conta = new Conta("0001-1","10.001-1");
		
		System.out.println("Informe o CPF: ");
		conta.cpfTitular = leia.nextLine();
		System.out.println("Informe o nome: ");
		conta.nome = leia.nextLine(); 
		
		
		conta.exibirDados();
		
		
		//fecha objeto leia
		leia.close();
		
		//
	}

}
