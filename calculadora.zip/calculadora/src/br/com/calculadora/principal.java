package br.com.calculadora;

import java.util.Scanner;

public class principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//instancia o objetos dac classe calculadora
		Calculadora calculadora = new Calculadora();
		Scanner leia = new Scanner(System.in);
		
		System.out.println("Informeo 1� n�mero:");
		calculadora.x = leia.nextDouble();
		System.out.println("Informe o 2� numero:");
		calculadora.y = leia.nextDouble();
		
		//limpeza de buffer
		leia.nextLine();
		
		System.out.println("Informe o operador:");
		System.out.println("+ = soma");
		System.out.println("- = Subtra��o");
		System.out.println("* = Multiplica��o");
		System.out.println("/ = Divis�o");
		calculadora.operador = leia.nextLine();
		
		//escolha,,caso
		switch (calculadora.operador) {
		    case "+": 
		       System.out.println("Resultado: " + calculadora.somar());
		       break;
		    case "-":
		    	System.out.println("Resultado: " + calculadora.subtrair());
		    	break;
		    case "*":
		    	System.out.println("Resultado: " + calculadora.multiplicar());
		    	break;
		    case "/":
		    	System.out.println("Resultado: " + calculadora.dividir());
		    	break;
		    default:
		    	System.out.println("Op��o inv�lida.");
		    	break;
		    	
		}
		
		
		
	}

}
